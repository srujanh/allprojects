package com.ticketsystem.command;

/**
 * Created by rohitkumar on 04/02/17.
 */
public interface Command<T> {

    String execute();
}
