package com.sts.redis.repository;

import com.sts.redis.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmployeeRepository implements EmployeeDao{

    public static final String HASH_KEY = "Employee";

    @Autowired
    private RedisTemplate redisTemplate;

    @Override
    public Employee saveEmployee(Employee emp) {
        redisTemplate.opsForHash().put(HASH_KEY, emp.getId().toString(), emp);
        return emp;
    }

    @Override
    public List<Employee> fetchAllEmployees() {
        return redisTemplate.opsForHash().values(HASH_KEY);
    }

    @Override
    public Employee fetchEmployeeById(Long id) {
        System.out.println("Data fetched from DB");
        return (Employee) redisTemplate.opsForHash().get(HASH_KEY, id.toString());
    }

    @Override
    public String deleteEmployee(Long id) {
        redisTemplate.opsForHash().delete(HASH_KEY, id.toString());
        return "Employee removed";
    }
}