package com.sts.redis.service;

import com.sts.redis.model.Employee;
import com.sts.redis.repository.EmployeeDao;
import com.sts.redis.repository.EmployeeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    public Employee saveEmployee(Employee employee) {
        return employeeRepository.saveEmployee(employee);
    }

    public List<Employee> fetchAllEmployees() {
        return employeeRepository.fetchAllEmployees();
    }

    public Employee fetchUserById(Long id) {
        return employeeRepository.fetchEmployeeById(id);
    }

    public String deleteEmployee(Long id) {
        return employeeRepository.deleteEmployee(id);
    }
}