package com.sts.redis.controller;

import com.sts.redis.model.Employee;
import com.sts.redis.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/employee")
    public Employee saveEmployee(@RequestBody Employee employee) {
        return employeeService.saveEmployee(employee);
    }

    @GetMapping("/employee")
    public List<Employee> getAllEmployees() {
        return employeeService.fetchAllEmployees();
    }

    @GetMapping("/employee/{id}")
    @Cacheable(key = "#id",value = "Employee",unless = "#result.salary > 10000")
    public Employee findEmployee(@PathVariable Long id) {
        return employeeService.fetchUserById(id);
    }

    @DeleteMapping("/employee/{id}")
    @CacheEvict(key = "#id",value = "Employee")
    public String removeEmployee(@PathVariable Long id) {
        return employeeService.deleteEmployee(id);
    }
}