package com.sts.redis.repository;

import com.sts.redis.model.Employee;

import java.util.List;

public interface EmployeeDao {
    Employee saveEmployee(Employee emp);

    List<Employee> fetchAllEmployees();

    Employee fetchEmployeeById(Long id);

    String deleteEmployee(Long id);
}