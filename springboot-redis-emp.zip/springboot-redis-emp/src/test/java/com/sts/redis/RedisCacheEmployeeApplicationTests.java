package com.sts.redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedisCacheEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
