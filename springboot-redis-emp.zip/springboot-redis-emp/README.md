# Getting Started

### Endpoint details

Post
http://127.0.0.1:9100/rediscache/api/employee/

Put
http://127.0.0.1:9100/rediscache/api/employee/

Get
http://127.0.0.1:9100/rediscache/api/employee/

Get
http://127.0.0.1:9100/rediscache/api/employee/1

Delete
http://127.0.0.1:9100/rediscache/api/employee/1


### Data details

{
"id": "1",
"name": "Amith",
"address": "Bangalore",
"salary": "15000"
}

{
"id": "2",
"name": "Viaan",
"address": "Bangalore",
"salary": "14000"
}

{
"id": "3",
"name": "Samhitha",
"address": "Bangalore",
"salary": "24000"
}

