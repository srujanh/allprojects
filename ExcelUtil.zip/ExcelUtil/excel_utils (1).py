"""
excel_utils.py
================
A comprehensive Excel utility module built on top of `openpyxl`.

Install dependency:
    pip install openpyxl

This module wraps common Excel operations into a single `ExcelUtil` class:
    - Workbook creation / loading / saving
    - Sheet creation, deletion, renaming, copying, ordering
    - Reading and writing cells, rows, columns, ranges
    - Formatting (fonts, fills, borders, alignment, number formats)
    - Merging / unmerging cells
    - Freeze panes, row/column dimensions, hide/show
    - Formulas
    - Data validation
    - Conditional formatting
    - Charts (bar, line, pie)
    - Images
    - Tables (Excel native tables)
    - Filtering / sorting helpers (via pandas, optional)
    - Protection (sheet / workbook password)
    - Utility helpers (column letter <-> index, etc.)

Usage example:
    from excel_utils import ExcelUtil

    xl = ExcelUtil()                      # new workbook
    xl.create_sheet("Report")
    xl.write_row("Report", 1, ["Name", "Score"])
    xl.write_row("Report", 2, ["Alice", 92])
    xl.bold_range("Report", "A1:B1")
    xl.save("report.xlsx")

    xl2 = ExcelUtil("report.xlsx")        # load existing
    print(xl2.read_cell("Report", "A1"))
"""

from __future__ import annotations

import os
from typing import Any, Iterable, List, Optional, Sequence, Union

from openpyxl import Workbook, load_workbook
from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.utils import get_column_letter, column_index_from_string
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment, NamedStyle
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.formatting.rule import (
    ColorScaleRule,
    CellIsRule,
    FormulaRule,
    IconSetRule,
    DataBarRule,
)
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.chart import BarChart, LineChart, PieChart, ScatterChart, Reference, Series
from openpyxl.drawing.image import Image as XLImage
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils.exceptions import InvalidFileException


class ExcelUtil:
    """High level wrapper around openpyxl for common Excel operations."""

    # ------------------------------------------------------------------ #
    # Construction / IO
    # ------------------------------------------------------------------ #
    def __init__(self, filepath: Optional[str] = None):
        """
        If `filepath` is given and exists, the workbook is loaded.
        Otherwise a new blank workbook is created.
        """
        self.filepath = filepath
        if filepath and os.path.exists(filepath):
            self.wb: Workbook = load_workbook(filepath)
        else:
            self.wb = Workbook()

    @classmethod
    def new(cls) -> "ExcelUtil":
        """
        Create a brand-new blank workbook (explicit alternative to __init__).

        Example:
            xl = ExcelUtil.new()
        """
        return cls()

    @classmethod
    def load(cls, filepath: str, data_only: bool = False, read_only: bool = False) -> "ExcelUtil":
        """
        Load an existing workbook.
        data_only=True  -> read cached formula results instead of formulas.
        read_only=True  -> faster loading for very large files (limits editing).

        Example:
            xl = ExcelUtil.load("report.xlsx")
            xl = ExcelUtil.load("report.xlsx", data_only=True)
        """
        util = cls.__new__(cls)
        util.filepath = filepath
        util.wb = load_workbook(filepath, data_only=data_only, read_only=read_only)
        return util

    def save(self, filepath: Optional[str] = None) -> str:
        """
        Save the workbook. Uses original path if none given.

        Example:
            xl.save("report.xlsx")
        """
        path = filepath or self.filepath
        if not path:
            raise ValueError("No filepath provided to save the workbook.")
        self.wb.save(path)
        self.filepath = path
        return path

    def close(self):
        """
        Close the workbook (relevant mainly for read_only/write_only modes).

        Example:
            xl.close()
        """
        self.wb.close()

    # ------------------------------------------------------------------ #
    # Sheet management
    # ------------------------------------------------------------------ #
    def sheet_names(self) -> List[str]:
        """
        Return a list of all sheet names in the workbook.

        Example:
            xl.sheet_names()
            # ['Report', 'Summary']
        """
        return self.wb.sheetnames

    def get_sheet(self, name: Optional[str] = None) -> Worksheet:
        """
        Return the underlying openpyxl Worksheet object; defaults to the
        active sheet. Useful for calling openpyxl APIs not wrapped here.

        Example:
            ws = xl.get_sheet("Report")
            ws = xl.get_sheet()   # active sheet
        """
        if name is None:
            return self.wb.active
        if name not in self.wb.sheetnames:
            raise KeyError(f"Sheet '{name}' does not exist.")
        return self.wb[name]

    def create_sheet(self, name: str, index: Optional[int] = None) -> Worksheet:
        """
        Create a new sheet. If it already exists, returns the existing one.

        Example:
            xl.create_sheet("Report")
            xl.create_sheet("Summary", index=0)   # insert as first sheet
        """
        if name in self.wb.sheetnames:
            return self.wb[name]
        return self.wb.create_sheet(title=name, index=index)

    def delete_sheet(self, name: str):
        """
        Delete a sheet by name.

        Example:
            xl.delete_sheet("Sheet")   # remove openpyxl's default sheet
        """
        del self.wb[name]

    def rename_sheet(self, old_name: str, new_name: str):
        """
        Rename an existing sheet.

        Example:
            xl.rename_sheet("Sheet1", "Report")
        """
        ws = self.get_sheet(old_name)
        ws.title = new_name

    def copy_sheet(self, source_name: str, new_name: str) -> Worksheet:
        """
        Duplicate a sheet (including values and formatting) under a new name.

        Example:
            xl.copy_sheet("Report", "Report Backup")
        """
        source = self.get_sheet(source_name)
        target = self.wb.copy_worksheet(source)
        target.title = new_name
        return target

    def set_active_sheet(self, name: str):
        """
        Set which sheet is active (shown) when the workbook is opened.

        Example:
            xl.set_active_sheet("Summary")
        """
        self.wb.active = self.wb.sheetnames.index(name)

    def reorder_sheets(self, order: Sequence[str]):
        """
        Reorder sheets according to the given sequence of sheet names.

        Example:
            xl.reorder_sheets(["Summary", "Report", "Raw Data"])
        """
        self.wb._sheets.sort(key=lambda ws: order.index(ws.title))

    def hide_sheet(self, name: str, state: str = "hidden"):
        """
        Set a sheet's visibility. state: 'visible' | 'hidden' | 'veryHidden'.

        Example:
            xl.hide_sheet("Raw Data")
            xl.hide_sheet("Raw Data", state="visible")  # unhide
        """
        self.get_sheet(name).sheet_state = state

    # ------------------------------------------------------------------ #
    # Cell / range read & write
    # ------------------------------------------------------------------ #
    def write_cell(self, sheet: str, cell: str, value: Any):
        """
        Write a single value into a cell.

        Example:
            xl.write_cell("Report", "A1", "Name")
            xl.write_cell("Report", "B1", 100)
        """
        self.get_sheet(sheet)[cell] = value

    def read_cell(self, sheet: str, cell: str) -> Any:
        """
        Read the value of a single cell.

        Example:
            name = xl.read_cell("Report", "A1")
            # 'Name'
        """
        return self.get_sheet(sheet)[cell].value

    def write_row(self, sheet: str, row: int, values: Sequence[Any], start_col: int = 1):
        """
        Write a list of values across a row, starting at `start_col`.

        Example:
            xl.write_row("Report", 1, ["Name", "Score", "Passed"])
            xl.write_row("Report", 2, ["Alice", 92, True])
        """
        ws = self.get_sheet(sheet)
        for i, val in enumerate(values):
            ws.cell(row=row, column=start_col + i, value=val)

    def write_column(self, sheet: str, col: int, values: Sequence[Any], start_row: int = 1):
        """
        Write a list of values down a column, starting at `start_row`.

        Example:
            xl.write_column("Report", 1, ["Alice", "Bob", "Carol"])
        """
        ws = self.get_sheet(sheet)
        for i, val in enumerate(values):
            ws.cell(row=start_row + i, column=col, value=val)

    def write_rows(self, sheet: str, rows: Iterable[Sequence[Any]], start_row: int = 1, start_col: int = 1):
        """
        Write a 2D iterable of rows starting at (start_row, start_col).

        Example:
            xl.write_rows("Report", [
                ["Name", "Score"],
                ["Alice", 92],
                ["Bob", 67],
            ])
        """
        ws = self.get_sheet(sheet)
        for r_off, row in enumerate(rows):
            for c_off, val in enumerate(row):
                ws.cell(row=start_row + r_off, column=start_col + c_off, value=val)

    def append_row(self, sheet: str, values: Sequence[Any]):
        """
        Append a row of values after the last used row.

        Example:
            xl.append_row("Report", ["Dave", 74, False])
        """
        self.get_sheet(sheet).append(list(values))

    def read_row(self, sheet: str, row: int, min_col: int = 1, max_col: Optional[int] = None) -> List[Any]:
        """
        Read all values in a row as a list.

        Example:
            headers = xl.read_row("Report", 1)
            # ['Name', 'Score', 'Passed']
        """
        ws = self.get_sheet(sheet)
        max_col = max_col or ws.max_column
        return [ws.cell(row=row, column=c).value for c in range(min_col, max_col + 1)]

    def read_column(self, sheet: str, col: int, min_row: int = 1, max_row: Optional[int] = None) -> List[Any]:
        """
        Read all values in a column as a list.

        Example:
            names = xl.read_column("Report", 1)
            # ['Name', 'Alice', 'Bob', 'Carol']
        """
        ws = self.get_sheet(sheet)
        max_row = max_row or ws.max_row
        return [ws.cell(row=r, column=col).value for r in range(min_row, max_row + 1)]

    def read_range(self, sheet: str, cell_range: str) -> List[List[Any]]:
        """
        Read a rectangular range of cells as a list of rows.

        Example:
            rows = xl.read_range("Report", "A1:C3")
        """
        ws = self.get_sheet(sheet)
        return [[cell.value for cell in row] for row in ws[cell_range]]

    def read_all(self, sheet: str, with_header: bool = True) -> List[List[Any]]:
        """
        Read the entire used range of a sheet as a list of rows.

        Example:
            data = xl.read_all("Report")
            data = xl.read_all("Report", with_header=False)  # skip row 1
        """
        ws = self.get_sheet(sheet)
        data = [list(row) for row in ws.iter_rows(values_only=True)]
        return data if with_header else data[1:]

    def filter_rows(self, sheet: str, column: Union[str, int], value: Any,
                     header_row: int = 1, as_dict: bool = False,
                     match: str = "exact", case_sensitive: bool = False) -> List[Union[List[Any], dict]]:
        """
        Filter rows by a column, matched either by header name or column
        letter/index, and return the matching rows (header row excluded).

        column: header name (e.g. 'Score'), column letter (e.g. 'B'),
                or 1-based column index (e.g. 2).
        value:  the value to match against.
        header_row: row number containing headers (default 1). Only used
                    when `column` is a header name.
        as_dict: if True, each returned row is a dict keyed by header name
                 instead of a plain list.
        match:  'exact' (default), 'contains', 'startswith', 'endswith'
                 — string comparisons only apply when cell value is a str.
        case_sensitive: whether string comparisons are case sensitive.

        Returns: list of rows (each a list of cell values, or dict if
                  as_dict=True) whose value in the target column matches.

        Example:
            # Sheet 'Report' has headers: Name | Score | Passed
            xl.filter_rows("Report", "Name", "Alice")
            # [['Alice', 92, True]]

            xl.filter_rows("Report", "Passed", True, as_dict=True)
            # [{'Name': 'Alice', 'Score': 92, 'Passed': True}, ...]

            xl.filter_rows("Report", "Name", "ali", match="contains")
            # case-insensitive substring match

            xl.filter_rows("Report", "B", 90)   # by column letter
            xl.filter_rows("Report", 2, 90)     # by column index
        """
        ws = self.get_sheet(sheet)
        headers = self.read_row(sheet, header_row)

        # Resolve target column index
        if isinstance(column, int):
            col_idx = column
        elif isinstance(column, str) and column.isalpha() and column.upper() in [
            get_column_letter(i) for i in range(1, ws.max_column + 1)
        ] and column not in headers:
            col_idx = column_index_from_string(column.upper())
        else:
            if column not in headers:
                raise ValueError(f"Column '{column}' not found in header row {header_row}: {headers}")
            col_idx = headers.index(column) + 1

        def _matches(cell_val: Any) -> bool:
            if cell_val is None:
                return False
            if isinstance(cell_val, str) and isinstance(value, str):
                a, b = cell_val, value
                if not case_sensitive:
                    a, b = a.lower(), b.lower()
                if match == "exact":
                    return a == b
                elif match == "contains":
                    return b in a
                elif match == "startswith":
                    return a.startswith(b)
                elif match == "endswith":
                    return a.endswith(b)
                else:
                    raise ValueError(f"Unknown match mode: {match}")
            return cell_val == value

        results = []
        for row_idx in range(header_row + 1, ws.max_row + 1):
            cell_val = ws.cell(row=row_idx, column=col_idx).value
            if _matches(cell_val):
                row_values = [ws.cell(row=row_idx, column=c).value for c in range(1, ws.max_column + 1)]
                if as_dict:
                    results.append(dict(zip(headers, row_values)))
                else:
                    results.append(row_values)
        return results

    def iter_rows(self, sheet: str, **kwargs):
        """
        Passthrough to openpyxl's iter_rows for advanced/streaming use.

        Example:
            for row in xl.iter_rows("Report", min_row=2, values_only=True):
                print(row)
        """
        return self.get_sheet(sheet).iter_rows(**kwargs)

    def clear_range(self, sheet: str, cell_range: str):
        """
        Clear the values of every cell in a range (formatting is kept).

        Example:
            xl.clear_range("Report", "A2:C10")
        """
        ws = self.get_sheet(sheet)
        for row in ws[cell_range]:
            for cell in row:
                cell.value = None

    def delete_row(self, sheet: str, row: int, amount: int = 1):
        """
        Delete one or more rows, shifting rows below upward.

        Example:
            xl.delete_row("Report", 3)          # delete row 3
            xl.delete_row("Report", 3, amount=2)  # delete rows 3-4
        """
        self.get_sheet(sheet).delete_rows(row, amount)

    def delete_column(self, sheet: str, col: int, amount: int = 1):
        """
        Delete one or more columns, shifting columns to the right leftward.

        Example:
            xl.delete_column("Report", 2)   # delete column B
        """
        self.get_sheet(sheet).delete_cols(col, amount)

    def insert_row(self, sheet: str, row: int, amount: int = 1):
        """
        Insert one or more blank rows before the given row number.

        Example:
            xl.insert_row("Report", 2)   # new blank row at position 2
        """
        self.get_sheet(sheet).insert_rows(row, amount)

    def insert_column(self, sheet: str, col: int, amount: int = 1):
        """
        Insert one or more blank columns before the given column index.

        Example:
            xl.insert_column("Report", 2)   # new blank column at B
        """
        self.get_sheet(sheet).insert_cols(col, amount)

    def max_row(self, sheet: str) -> int:
        """
        Return the highest used row number in the sheet.

        Example:
            xl.max_row("Report")
            # 4
        """
        return self.get_sheet(sheet).max_row

    def max_col(self, sheet: str) -> int:
        """
        Return the highest used column index in the sheet.

        Example:
            xl.max_col("Report")
            # 3
        """
        return self.get_sheet(sheet).max_column

    # ------------------------------------------------------------------ #
    # Formulas
    # ------------------------------------------------------------------ #
    def write_formula(self, sheet: str, cell: str, formula: str):
        """
        Write a formula into a cell. formula should start with '=',
        e.g. '=SUM(A1:A10)' (the '=' is added automatically if omitted).

        Example:
            xl.write_formula("Report", "B5", "=SUM(B2:B4)")
            xl.write_formula("Report", "C5", "AVERAGE(C2:C4)")  # '=' added
        """
        if not formula.startswith("="):
            formula = "=" + formula
        self.get_sheet(sheet)[cell] = formula

    # ------------------------------------------------------------------ #
    # Formatting
    # ------------------------------------------------------------------ #
    def set_font(self, sheet: str, cell_range: str, bold: bool = False, italic: bool = False,
                 size: int = 11, color: str = "000000", name: str = "Calibri", underline: Optional[str] = None):
        """
        Apply a font style to every cell in a range. color is a hex RGB
        string without '#' (e.g. 'FF0000' for red).

        Example:
            xl.set_font("Report", "A1:C1", bold=True, size=13, color="1F4E78")
        """
        font = Font(bold=bold, italic=italic, size=size, color=color, name=name, underline=underline)
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.font = font

    def bold_range(self, sheet: str, cell_range: str):
        """
        Shortcut for making a range of cells bold.

        Example:
            xl.bold_range("Report", "A1:C1")
        """
        self.set_font(sheet, cell_range, bold=True)

    def set_fill(self, sheet: str, cell_range: str, color: str = "FFFF00", fill_type: str = "solid"):
        """
        Fill a range of cells with a background color (hex RGB, no '#').

        Example:
            xl.set_fill("Report", "A1:C1", color="D9E1F2")
        """
        fill = PatternFill(start_color=color, end_color=color, fill_type=fill_type)
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.fill = fill

    def set_border(self, sheet: str, cell_range: str, style: str = "thin", color: str = "000000"):
        """
        Add a border around every cell in a range.
        style options include: 'thin', 'medium', 'thick', 'dashed', 'dotted'.

        Example:
            xl.set_border("Report", "A1:C4")
            xl.set_border("Report", "A1:C1", style="thick", color="FF0000")
        """
        side = Side(style=style, color=color)
        border = Border(left=side, right=side, top=side, bottom=side)
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.border = border

    def set_alignment(self, sheet: str, cell_range: str, horizontal: str = "center",
                       vertical: str = "center", wrap_text: bool = False):
        """
        Set text alignment for a range of cells.

        Example:
            xl.set_alignment("Report", "A1:C1", horizontal="center")
            xl.set_alignment("Report", "D2:D10", wrap_text=True)
        """
        alignment = Alignment(horizontal=horizontal, vertical=vertical, wrap_text=wrap_text)
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.alignment = alignment

    def set_number_format(self, sheet: str, cell_range: str, fmt: str = "0.00"):
        """
        Common formats:
            '0.00'          -> 2 decimals
            '#,##0'         -> thousands separator
            '0.00%'         -> percentage
            'yyyy-mm-dd'    -> date
            '$#,##0.00'     -> currency

        Example:
            xl.set_number_format("Report", "B2:B10", fmt="$#,##0.00")
            xl.set_number_format("Report", "C2:C10", fmt="0.0%")
        """
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.number_format = fmt

    def register_named_style(self, style_name: str, font: Optional[Font] = None,
                              fill: Optional[PatternFill] = None, border: Optional[Border] = None,
                              alignment: Optional[Alignment] = None, number_format: Optional[str] = None):
        """
        Create and register a reusable named style on the workbook, so it
        can be applied by name with apply_named_style().

        Example:
            xl.register_named_style(
                "header_style",
                font=Font(bold=True, color="FFFFFF"),
                fill=PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid"),
            )
            xl.apply_named_style("Report", "A1:C1", "header_style")
        """
        if style_name in self.wb.named_styles:
            return
        style = NamedStyle(name=style_name)
        if font:
            style.font = font
        if fill:
            style.fill = fill
        if border:
            style.border = border
        if alignment:
            style.alignment = alignment
        if number_format:
            style.number_format = number_format
        self.wb.add_named_style(style)

    def apply_named_style(self, sheet: str, cell_range: str, style_name: str):
        """
        Apply a previously registered named style to a range of cells.

        Example:
            xl.apply_named_style("Report", "A1:C1", "header_style")
        """
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.style = style_name

    # ------------------------------------------------------------------ #
    # Column / row dimensions
    # ------------------------------------------------------------------ #
    def set_column_width(self, sheet: str, col: Union[str, int], width: float):
        """
        Set a column's width. Accepts a column letter or 1-based index.

        Example:
            xl.set_column_width("Report", "A", 25)
            xl.set_column_width("Report", 1, 25)
        """
        letter = col if isinstance(col, str) else get_column_letter(col)
        self.get_sheet(sheet).column_dimensions[letter].width = width

    def set_row_height(self, sheet: str, row: int, height: float):
        """
        Set a row's height in points.

        Example:
            xl.set_row_height("Report", 1, 22)
        """
        self.get_sheet(sheet).row_dimensions[row].height = height

    def autosize_columns(self, sheet: str, min_width: int = 8, max_width: int = 60):
        """
        Approximate auto-fit of column widths based on cell content length.

        Example:
            xl.autosize_columns("Report")
        """
        ws = self.get_sheet(sheet)
        widths = {}
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is None:
                    continue
                col_letter = cell.column_letter
                length = len(str(cell.value))
                widths[col_letter] = max(widths.get(col_letter, min_width), length + 2)
        for col_letter, width in widths.items():
            ws.column_dimensions[col_letter].width = min(width, max_width)

    def hide_column(self, sheet: str, col: Union[str, int], hidden: bool = True):
        """
        Hide or show a column.

        Example:
            xl.hide_column("Report", "D")
            xl.hide_column("Report", "D", hidden=False)  # unhide
        """
        letter = col if isinstance(col, str) else get_column_letter(col)
        self.get_sheet(sheet).column_dimensions[letter].hidden = hidden

    def hide_row(self, sheet: str, row: int, hidden: bool = True):
        """
        Hide or show a row.

        Example:
            xl.hide_row("Report", 5)
        """
        self.get_sheet(sheet).row_dimensions[row].hidden = hidden

    # ------------------------------------------------------------------ #
    # Merge / freeze / view
    # ------------------------------------------------------------------ #
    def merge_cells(self, sheet: str, cell_range: str):
        """
        Merge a rectangular range of cells into one.

        Example:
            xl.merge_cells("Report", "A1:C1")
        """
        self.get_sheet(sheet).merge_cells(cell_range)

    def unmerge_cells(self, sheet: str, cell_range: str):
        """
        Undo a previous cell merge.

        Example:
            xl.unmerge_cells("Report", "A1:C1")
        """
        self.get_sheet(sheet).unmerge_cells(cell_range)

    def freeze_panes(self, sheet: str, cell: str = "A2"):
        """
        Freeze rows/columns above and to the left of `cell`.

        Example:
            xl.freeze_panes("Report", "A2")   # freeze header row
            xl.freeze_panes("Report", "B2")   # freeze row 1 and column A
        """
        self.get_sheet(sheet).freeze_panes = cell

    def set_zoom(self, sheet: str, scale: int = 100):
        """
        Set the sheet's zoom level as a percentage.

        Example:
            xl.set_zoom("Report", 125)
        """
        self.get_sheet(sheet).sheet_view.zoomScale = scale

    def set_gridlines_visible(self, sheet: str, visible: bool = True):
        """
        Show or hide gridlines on a sheet.

        Example:
            xl.set_gridlines_visible("Report", False)
        """
        self.get_sheet(sheet).sheet_view.showGridLines = visible

    def set_tab_color(self, sheet: str, color: str = "FF0000"):
        """
        Color a sheet's tab (hex RGB, no '#').

        Example:
            xl.set_tab_color("Report", "00B050")
        """
        self.get_sheet(sheet).sheet_properties.tabColor = color

    def auto_filter(self, sheet: str, cell_range: str):
        """
        Add Excel's built-in filter dropdowns to a header range.

        Example:
            xl.auto_filter("Report", "A1:C4")
        """
        self.get_sheet(sheet).auto_filter.ref = cell_range

    # ------------------------------------------------------------------ #
    # Data validation
    # ------------------------------------------------------------------ #
    def add_dropdown_validation(self, sheet: str, cell_range: str, options: Sequence[str]):
        """
        Add an in-cell dropdown list validation.

        Example:
            xl.add_dropdown_validation("Report", "C2:C100", ["Yes", "No"])
        """
        formula = '"' + ",".join(options) + '"'
        dv = DataValidation(type="list", formula1=formula, allow_blank=True)
        ws = self.get_sheet(sheet)
        ws.add_data_validation(dv)
        dv.add(cell_range)

    def add_number_validation(self, sheet: str, cell_range: str, min_value: float, max_value: float):
        """
        Restrict a range of cells to a numeric value between min and max.

        Example:
            xl.add_number_validation("Report", "B2:B100", min_value=0, max_value=100)
        """
        dv = DataValidation(type="decimal", operator="between",
                             formula1=str(min_value), formula2=str(max_value), allow_blank=True)
        ws = self.get_sheet(sheet)
        ws.add_data_validation(dv)
        dv.add(cell_range)

    # ------------------------------------------------------------------ #
    # Conditional formatting
    # ------------------------------------------------------------------ #
    def add_color_scale(self, sheet: str, cell_range: str,
                         start_color: str = "FF0000", end_color: str = "00FF00"):
        """
        Apply a two-color scale (low -> high) across a numeric range.

        Example:
            xl.add_color_scale("Report", "B2:B100", start_color="FF0000", end_color="00B050")
        """
        rule = ColorScaleRule(
            start_type="min", start_color=start_color,
            end_type="max", end_color=end_color,
        )
        self.get_sheet(sheet).conditional_formatting.add(cell_range, rule)

    def add_cell_highlight_rule(self, sheet: str, cell_range: str, operator: str,
                                 formula: List[str], fill_color: str = "FFC7CE"):
        """
        Highlight cells whose value matches a comparison.
        operator examples: 'greaterThan', 'lessThan', 'equal', 'between'
        formula: list of formula strings, e.g. ['100']

        Example:
            xl.add_cell_highlight_rule("Report", "B2:B100", operator="lessThan", formula=["70"])
            xl.add_cell_highlight_rule("Report", "B2:B100", operator="between", formula=["70", "89"])
        """
        fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
        rule = CellIsRule(operator=operator, formula=formula, fill=fill)
        self.get_sheet(sheet).conditional_formatting.add(cell_range, rule)

    def add_formula_rule(self, sheet: str, cell_range: str, formula: str, fill_color: str = "FFEB9C"):
        """
        Highlight cells based on a custom formula (relative to the top-left
        cell of the range).

        Example:
            xl.add_formula_rule("Report", "A2:C100", formula="$C2=FALSE")
        """
        fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
        rule = FormulaRule(formula=[formula], fill=fill)
        self.get_sheet(sheet).conditional_formatting.add(cell_range, rule)

    def add_data_bars(self, sheet: str, cell_range: str, color: str = "638EC6"):
        """
        Add in-cell data bars (mini bar chart) to a numeric range.

        Example:
            xl.add_data_bars("Report", "B2:B100")
        """
        rule = DataBarRule(start_type="min", end_type="max", color=color)
        self.get_sheet(sheet).conditional_formatting.add(cell_range, rule)

    # ------------------------------------------------------------------ #
    # Charts
    # ------------------------------------------------------------------ #
    def add_bar_chart(self, sheet: str, data_range: str, categories_range: str,
                       anchor: str = "E2", title: str = "", x_title: str = "", y_title: str = ""):
        """
        Insert a bar chart. data_range should include the header row
        (used as the series title); categories_range excludes it.

        Example:
            xl.add_bar_chart("Report", data_range="B1:B4", categories_range="A2:A4",
                              anchor="E2", title="Scores", x_title="Student", y_title="Score")
        """
        ws = self.get_sheet(sheet)
        chart = BarChart()
        chart.title = title
        chart.x_axis.title = x_title
        chart.y_axis.title = y_title
        data = Reference(ws, range_string=f"{sheet}!{data_range}")
        cats = Reference(ws, range_string=f"{sheet}!{categories_range}")
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)
        ws.add_chart(chart, anchor)
        return chart

    def add_line_chart(self, sheet: str, data_range: str, categories_range: str,
                        anchor: str = "E2", title: str = ""):
        """
        Insert a line chart. data_range should include the header row.

        Example:
            xl.add_line_chart("Report", data_range="B1:B10", categories_range="A2:A10",
                               anchor="E2", title="Trend")
        """
        ws = self.get_sheet(sheet)
        chart = LineChart()
        chart.title = title
        data = Reference(ws, range_string=f"{sheet}!{data_range}")
        cats = Reference(ws, range_string=f"{sheet}!{categories_range}")
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)
        ws.add_chart(chart, anchor)
        return chart

    def add_pie_chart(self, sheet: str, data_range: str, categories_range: str,
                       anchor: str = "E2", title: str = ""):
        """
        Insert a pie chart. data_range should include the header row.

        Example:
            xl.add_pie_chart("Report", data_range="B1:B5", categories_range="A2:A5",
                              anchor="E2", title="Market Share")
        """
        ws = self.get_sheet(sheet)
        chart = PieChart()
        chart.title = title
        data = Reference(ws, range_string=f"{sheet}!{data_range}")
        cats = Reference(ws, range_string=f"{sheet}!{categories_range}")
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)
        ws.add_chart(chart, anchor)
        return chart

    def add_scatter_chart(self, sheet: str, x_range: str, y_range: str,
                           anchor: str = "E2", title: str = ""):
        """
        Insert an X/Y scatter chart. x_range and y_range should include a
        header cell each, used as the series title.

        Example:
            xl.add_scatter_chart("Report", x_range="A1:A10", y_range="B1:B10",
                                  anchor="E2", title="Height vs Weight")
        """
        ws = self.get_sheet(sheet)
        chart = ScatterChart()
        chart.title = title
        xvalues = Reference(ws, range_string=f"{sheet}!{x_range}")
        yvalues = Reference(ws, range_string=f"{sheet}!{y_range}")
        series = Series(yvalues, xvalues, title_from_data=True)
        chart.series.append(series)
        ws.add_chart(chart, anchor)
        return chart

    # ------------------------------------------------------------------ #
    # Images
    # ------------------------------------------------------------------ #
    def insert_image(self, sheet: str, image_path: str, anchor: str = "A1"):
        """
        Insert an image (png/jpg) into a sheet, anchored at a cell.

        Example:
            xl.insert_image("Report", "logo.png", anchor="E1")
        """
        img = XLImage(image_path)
        self.get_sheet(sheet).add_image(img, anchor)

    # ------------------------------------------------------------------ #
    # Native Excel Tables
    # ------------------------------------------------------------------ #
    def add_table(self, sheet: str, cell_range: str, table_name: str, style: str = "TableStyleMedium9"):
        """
        Convert a range into a native Excel table (with filter dropdowns
        and banded rows built in).

        Example:
            xl.add_table("Report", "A1:C4", table_name="ScoresTable")
        """
        ws = self.get_sheet(sheet)
        table = Table(displayName=table_name, ref=cell_range)
        table.tableStyleInfo = TableStyleInfo(
            name=style, showFirstColumn=False, showLastColumn=False,
            showRowStripes=True, showColumnStripes=False,
        )
        ws.add_table(table)
        return table

    # ------------------------------------------------------------------ #
    # Protection
    # ------------------------------------------------------------------ #
    def protect_sheet(self, sheet: str, password: Optional[str] = None):
        """
        Enable sheet protection, optionally with a password.

        Example:
            xl.protect_sheet("Report", password="secret")
        """
        self.get_sheet(sheet).protection.sheet = True
        if password:
            self.get_sheet(sheet).protection.password = password

    def unprotect_sheet(self, sheet: str):
        """
        Disable sheet protection.

        Example:
            xl.unprotect_sheet("Report")
        """
        self.get_sheet(sheet).protection.sheet = False

    def lock_cells(self, sheet: str, cell_range: str, locked: bool = True):
        """
        Lock or unlock a range of cells. Only takes effect once
        protect_sheet() is also called; by default all cells are locked,
        so this is typically used to unlock an "editable" range.

        Example:
            xl.lock_cells("Report", "B2:B100", locked=False)  # allow edits
            xl.protect_sheet("Report", password="secret")
        """
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.protection = cell.protection.copy(locked=locked)

    # ------------------------------------------------------------------ #
    # pandas interop (optional; requires pandas installed)
    # ------------------------------------------------------------------ #
    def write_dataframe(self, sheet: str, df, start_row: int = 1, start_col: int = 1,
                         index: bool = False, header: bool = True):
        """
        Write a pandas DataFrame into a sheet.

        Example:
            import pandas as pd
            df = pd.DataFrame({"Name": ["Alice", "Bob"], "Score": [92, 67]})
            xl.write_dataframe("Report", df)
        """
        ws = self.get_sheet(sheet)
        for r_off, row in enumerate(dataframe_to_rows(df, index=index, header=header)):
            for c_off, val in enumerate(row):
                ws.cell(row=start_row + r_off, column=start_col + c_off, value=val)

    def read_dataframe(self, sheet: str, header: bool = True):
        """
        Read a sheet into a pandas DataFrame.

        Example:
            df = xl.read_dataframe("Report")
        """
        import pandas as pd
        data = self.read_all(sheet)
        if header:
            return pd.DataFrame(data[1:], columns=data[0])
        return pd.DataFrame(data)

    # ------------------------------------------------------------------ #
    # Static utility helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def col_letter(index: int) -> str:
        """
        Convert a 1-based column index to its letter.

        Example:
            ExcelUtil.col_letter(1)    # 'A'
            ExcelUtil.col_letter(27)   # 'AA'
        """
        return get_column_letter(index)

    @staticmethod
    def col_index(letter: str) -> int:
        """
        Convert a column letter to its 1-based index.

        Example:
            ExcelUtil.col_index("A")    # 1
            ExcelUtil.col_index("AA")   # 27
        """
        return column_index_from_string(letter)

    @staticmethod
    def cell_address(row: int, col: int) -> str:
        """
        Build an A1-style cell address from a row and column number.

        Example:
            ExcelUtil.cell_address(2, 3)   # 'C2'
        """
        return f"{get_column_letter(col)}{row}"


# ---------------------------------------------------------------------- #
# Quick self-test / demo when run directly
# ---------------------------------------------------------------------- #
if __name__ == "__main__":
    xl = ExcelUtil.new()
    ws_name = "Demo"
    xl.create_sheet(ws_name)
    xl.delete_sheet("Sheet")  # remove default sheet

    xl.write_row(ws_name, 1, ["Name", "Score", "Passed"])
    xl.write_row(ws_name, 2, ["Alice", 92, True])
    xl.write_row(ws_name, 3, ["Bob", 67, False])
    xl.write_row(ws_name, 4, ["Carol", 88, True])

    xl.bold_range(ws_name, "A1:C1")
    xl.set_fill(ws_name, "A1:C1", color="D9E1F2")
    xl.set_border(ws_name, "A1:C4")
    xl.autosize_columns(ws_name)
    xl.freeze_panes(ws_name, "A2")
    xl.auto_filter(ws_name, "A1:C4")

    xl.write_formula(ws_name, "B5", "=AVERAGE(B2:B4)")
    xl.add_cell_highlight_rule(ws_name, "B2:B4", operator="lessThan", formula=["70"])

    xl.add_bar_chart(ws_name, data_range="B1:B4", categories_range="A2:A4",
                      anchor="E2", title="Scores", x_title="Student", y_title="Score")

    out_path = "excel_util_demo.xlsx"
    xl.save(out_path)
    print(f"Demo workbook written to {out_path}")
