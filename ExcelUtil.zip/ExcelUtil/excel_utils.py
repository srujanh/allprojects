"""
excel_utils.py
================
A comprehensive Excel utility module built on top of `openpyxl`.

Install dependency:
    pip install openpyxl

This module wraps common Excel operations into a single `ExcelUtil` class:
    - Workbook creation / loading / saving
    - Sheet creation, deletion, renaming, copying, ordering
    - Reading and writing cells, rows, columns, ranges
    - Formatting (fonts, fills, borders, alignment, number formats)
    - Merging / unmerging cells
    - Freeze panes, row/column dimensions, hide/show
    - Formulas
    - Data validation
    - Conditional formatting
    - Charts (bar, line, pie)
    - Images
    - Tables (Excel native tables)
    - Filtering / sorting helpers (via pandas, optional)
    - Protection (sheet / workbook password)
    - Utility helpers (column letter <-> index, etc.)

Usage example:
    from excel_utils import ExcelUtil

    xl = ExcelUtil()                      # new workbook
    xl.create_sheet("Report")
    xl.write_row("Report", 1, ["Name", "Score"])
    xl.write_row("Report", 2, ["Alice", 92])
    xl.bold_range("Report", "A1:B1")
    xl.save("report.xlsx")

    xl2 = ExcelUtil("report.xlsx")        # load existing
    print(xl2.read_cell("Report", "A1"))
"""

from __future__ import annotations

import os
from typing import Any, Iterable, List, Optional, Sequence, Union

from openpyxl import Workbook, load_workbook
from openpyxl.worksheet.worksheet import Worksheet
from openpyxl.utils import get_column_letter, column_index_from_string
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment, NamedStyle
from openpyxl.styles.differential import DifferentialStyle
from openpyxl.formatting.rule import (
    ColorScaleRule,
    CellIsRule,
    FormulaRule,
    IconSetRule,
    DataBarRule,
)
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.chart import BarChart, LineChart, PieChart, ScatterChart, Reference, Series
from openpyxl.drawing.image import Image as XLImage
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils.exceptions import InvalidFileException


class ExcelUtil:
    """High level wrapper around openpyxl for common Excel operations."""

    # ------------------------------------------------------------------ #
    # Construction / IO
    # ------------------------------------------------------------------ #
    def __init__(self, filepath: Optional[str] = None):
        """
        If `filepath` is given and exists, the workbook is loaded.
        Otherwise a new blank workbook is created.
        """
        self.filepath = filepath
        if filepath and os.path.exists(filepath):
            self.wb: Workbook = load_workbook(filepath)
        else:
            self.wb = Workbook()

    @classmethod
    def new(cls) -> "ExcelUtil":
        """Create a brand-new blank workbook (explicit alternative to __init__)."""
        return cls()

    @classmethod
    def load(cls, filepath: str, data_only: bool = False, read_only: bool = False) -> "ExcelUtil":
        """
        Load an existing workbook.
        data_only=True  -> read cached formula results instead of formulas.
        read_only=True  -> faster loading for very large files (limits editing).
        """
        util = cls.__new__(cls)
        util.filepath = filepath
        util.wb = load_workbook(filepath, data_only=data_only, read_only=read_only)
        return util

    def save(self, filepath: Optional[str] = None) -> str:
        """Save the workbook. Uses original path if none given."""
        path = filepath or self.filepath
        if not path:
            raise ValueError("No filepath provided to save the workbook.")
        self.wb.save(path)
        self.filepath = path
        return path

    def close(self):
        """Close the workbook (relevant mainly for read_only/write_only modes)."""
        self.wb.close()

    # ------------------------------------------------------------------ #
    # Sheet management
    # ------------------------------------------------------------------ #
    def sheet_names(self) -> List[str]:
        return self.wb.sheetnames

    def get_sheet(self, name: Optional[str] = None) -> Worksheet:
        """Return a worksheet object; defaults to the active sheet."""
        if name is None:
            return self.wb.active
        if name not in self.wb.sheetnames:
            raise KeyError(f"Sheet '{name}' does not exist.")
        return self.wb[name]

    def create_sheet(self, name: str, index: Optional[int] = None) -> Worksheet:
        """Create a new sheet. If it already exists, returns the existing one."""
        if name in self.wb.sheetnames:
            return self.wb[name]
        return self.wb.create_sheet(title=name, index=index)

    def delete_sheet(self, name: str):
        del self.wb[name]

    def rename_sheet(self, old_name: str, new_name: str):
        ws = self.get_sheet(old_name)
        ws.title = new_name

    def copy_sheet(self, source_name: str, new_name: str) -> Worksheet:
        source = self.get_sheet(source_name)
        target = self.wb.copy_worksheet(source)
        target.title = new_name
        return target

    def set_active_sheet(self, name: str):
        self.wb.active = self.wb.sheetnames.index(name)

    def reorder_sheets(self, order: Sequence[str]):
        """Reorder sheets according to the given sequence of sheet names."""
        self.wb._sheets.sort(key=lambda ws: order.index(ws.title))

    def hide_sheet(self, name: str, state: str = "hidden"):
        """state: 'visible' | 'hidden' | 'veryHidden'"""
        self.get_sheet(name).sheet_state = state

    # ------------------------------------------------------------------ #
    # Cell / range read & write
    # ------------------------------------------------------------------ #
    def write_cell(self, sheet: str, cell: str, value: Any):
        self.get_sheet(sheet)[cell] = value

    def read_cell(self, sheet: str, cell: str) -> Any:
        return self.get_sheet(sheet)[cell].value

    def write_row(self, sheet: str, row: int, values: Sequence[Any], start_col: int = 1):
        ws = self.get_sheet(sheet)
        for i, val in enumerate(values):
            ws.cell(row=row, column=start_col + i, value=val)

    def write_column(self, sheet: str, col: int, values: Sequence[Any], start_row: int = 1):
        ws = self.get_sheet(sheet)
        for i, val in enumerate(values):
            ws.cell(row=start_row + i, column=col, value=val)

    def write_rows(self, sheet: str, rows: Iterable[Sequence[Any]], start_row: int = 1, start_col: int = 1):
        """Write a 2D iterable of rows starting at (start_row, start_col)."""
        ws = self.get_sheet(sheet)
        for r_off, row in enumerate(rows):
            for c_off, val in enumerate(row):
                ws.cell(row=start_row + r_off, column=start_col + c_off, value=val)

    def append_row(self, sheet: str, values: Sequence[Any]):
        self.get_sheet(sheet).append(list(values))

    def read_row(self, sheet: str, row: int, min_col: int = 1, max_col: Optional[int] = None) -> List[Any]:
        ws = self.get_sheet(sheet)
        max_col = max_col or ws.max_column
        return [ws.cell(row=row, column=c).value for c in range(min_col, max_col + 1)]

    def read_column(self, sheet: str, col: int, min_row: int = 1, max_row: Optional[int] = None) -> List[Any]:
        ws = self.get_sheet(sheet)
        max_row = max_row or ws.max_row
        return [ws.cell(row=r, column=col).value for r in range(min_row, max_row + 1)]

    def read_range(self, sheet: str, cell_range: str) -> List[List[Any]]:
        """e.g. read_range('Sheet1', 'A1:C10')"""
        ws = self.get_sheet(sheet)
        return [[cell.value for cell in row] for row in ws[cell_range]]

    def read_all(self, sheet: str, with_header: bool = True) -> List[List[Any]]:
        """Read the entire used range of a sheet as a list of rows."""
        ws = self.get_sheet(sheet)
        data = [list(row) for row in ws.iter_rows(values_only=True)]
        return data if with_header else data[1:]

    def iter_rows(self, sheet: str, **kwargs):
        """Passthrough to openpyxl's iter_rows for advanced/streaming use."""
        return self.get_sheet(sheet).iter_rows(**kwargs)

    def clear_range(self, sheet: str, cell_range: str):
        ws = self.get_sheet(sheet)
        for row in ws[cell_range]:
            for cell in row:
                cell.value = None

    def delete_row(self, sheet: str, row: int, amount: int = 1):
        self.get_sheet(sheet).delete_rows(row, amount)

    def delete_column(self, sheet: str, col: int, amount: int = 1):
        self.get_sheet(sheet).delete_cols(col, amount)

    def insert_row(self, sheet: str, row: int, amount: int = 1):
        self.get_sheet(sheet).insert_rows(row, amount)

    def insert_column(self, sheet: str, col: int, amount: int = 1):
        self.get_sheet(sheet).insert_cols(col, amount)

    def max_row(self, sheet: str) -> int:
        return self.get_sheet(sheet).max_row

    def max_col(self, sheet: str) -> int:
        return self.get_sheet(sheet).max_column

    # ------------------------------------------------------------------ #
    # Formulas
    # ------------------------------------------------------------------ #
    def write_formula(self, sheet: str, cell: str, formula: str):
        """formula should start with '=', e.g. '=SUM(A1:A10)'"""
        if not formula.startswith("="):
            formula = "=" + formula
        self.get_sheet(sheet)[cell] = formula

    # ------------------------------------------------------------------ #
    # Formatting
    # ------------------------------------------------------------------ #
    def set_font(self, sheet: str, cell_range: str, bold: bool = False, italic: bool = False,
                 size: int = 11, color: str = "000000", name: str = "Calibri", underline: Optional[str] = None):
        font = Font(bold=bold, italic=italic, size=size, color=color, name=name, underline=underline)
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.font = font

    def bold_range(self, sheet: str, cell_range: str):
        self.set_font(sheet, cell_range, bold=True)

    def set_fill(self, sheet: str, cell_range: str, color: str = "FFFF00", fill_type: str = "solid"):
        fill = PatternFill(start_color=color, end_color=color, fill_type=fill_type)
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.fill = fill

    def set_border(self, sheet: str, cell_range: str, style: str = "thin", color: str = "000000"):
        side = Side(style=style, color=color)
        border = Border(left=side, right=side, top=side, bottom=side)
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.border = border

    def set_alignment(self, sheet: str, cell_range: str, horizontal: str = "center",
                       vertical: str = "center", wrap_text: bool = False):
        alignment = Alignment(horizontal=horizontal, vertical=vertical, wrap_text=wrap_text)
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.alignment = alignment

    def set_number_format(self, sheet: str, cell_range: str, fmt: str = "0.00"):
        """
        Common formats:
            '0.00'          -> 2 decimals
            '#,##0'         -> thousands separator
            '0.00%'         -> percentage
            'yyyy-mm-dd'    -> date
            '$#,##0.00'     -> currency
        """
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.number_format = fmt

    def register_named_style(self, style_name: str, font: Optional[Font] = None,
                              fill: Optional[PatternFill] = None, border: Optional[Border] = None,
                              alignment: Optional[Alignment] = None, number_format: Optional[str] = None):
        """Create and register a reusable named style on the workbook."""
        if style_name in self.wb.named_styles:
            return
        style = NamedStyle(name=style_name)
        if font:
            style.font = font
        if fill:
            style.fill = fill
        if border:
            style.border = border
        if alignment:
            style.alignment = alignment
        if number_format:
            style.number_format = number_format
        self.wb.add_named_style(style)

    def apply_named_style(self, sheet: str, cell_range: str, style_name: str):
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.style = style_name

    # ------------------------------------------------------------------ #
    # Column / row dimensions
    # ------------------------------------------------------------------ #
    def set_column_width(self, sheet: str, col: Union[str, int], width: float):
        letter = col if isinstance(col, str) else get_column_letter(col)
        self.get_sheet(sheet).column_dimensions[letter].width = width

    def set_row_height(self, sheet: str, row: int, height: float):
        self.get_sheet(sheet).row_dimensions[row].height = height

    def autosize_columns(self, sheet: str, min_width: int = 8, max_width: int = 60):
        """Approximate auto-fit of column widths based on cell content length."""
        ws = self.get_sheet(sheet)
        widths = {}
        for row in ws.iter_rows():
            for cell in row:
                if cell.value is None:
                    continue
                col_letter = cell.column_letter
                length = len(str(cell.value))
                widths[col_letter] = max(widths.get(col_letter, min_width), length + 2)
        for col_letter, width in widths.items():
            ws.column_dimensions[col_letter].width = min(width, max_width)

    def hide_column(self, sheet: str, col: Union[str, int], hidden: bool = True):
        letter = col if isinstance(col, str) else get_column_letter(col)
        self.get_sheet(sheet).column_dimensions[letter].hidden = hidden

    def hide_row(self, sheet: str, row: int, hidden: bool = True):
        self.get_sheet(sheet).row_dimensions[row].hidden = hidden

    # ------------------------------------------------------------------ #
    # Merge / freeze / view
    # ------------------------------------------------------------------ #
    def merge_cells(self, sheet: str, cell_range: str):
        self.get_sheet(sheet).merge_cells(cell_range)

    def unmerge_cells(self, sheet: str, cell_range: str):
        self.get_sheet(sheet).unmerge_cells(cell_range)

    def freeze_panes(self, sheet: str, cell: str = "A2"):
        """Freeze rows/columns above and to the left of `cell`."""
        self.get_sheet(sheet).freeze_panes = cell

    def set_zoom(self, sheet: str, scale: int = 100):
        self.get_sheet(sheet).sheet_view.zoomScale = scale

    def set_gridlines_visible(self, sheet: str, visible: bool = True):
        self.get_sheet(sheet).sheet_view.showGridLines = visible

    def set_tab_color(self, sheet: str, color: str = "FF0000"):
        self.get_sheet(sheet).sheet_properties.tabColor = color

    def auto_filter(self, sheet: str, cell_range: str):
        self.get_sheet(sheet).auto_filter.ref = cell_range

    # ------------------------------------------------------------------ #
    # Data validation
    # ------------------------------------------------------------------ #
    def add_dropdown_validation(self, sheet: str, cell_range: str, options: Sequence[str]):
        """Add an in-cell dropdown list validation, e.g. options=['Yes','No']"""
        formula = '"' + ",".join(options) + '"'
        dv = DataValidation(type="list", formula1=formula, allow_blank=True)
        ws = self.get_sheet(sheet)
        ws.add_data_validation(dv)
        dv.add(cell_range)

    def add_number_validation(self, sheet: str, cell_range: str, min_value: float, max_value: float):
        dv = DataValidation(type="decimal", operator="between",
                             formula1=str(min_value), formula2=str(max_value), allow_blank=True)
        ws = self.get_sheet(sheet)
        ws.add_data_validation(dv)
        dv.add(cell_range)

    # ------------------------------------------------------------------ #
    # Conditional formatting
    # ------------------------------------------------------------------ #
    def add_color_scale(self, sheet: str, cell_range: str,
                         start_color: str = "FF0000", end_color: str = "00FF00"):
        rule = ColorScaleRule(
            start_type="min", start_color=start_color,
            end_type="max", end_color=end_color,
        )
        self.get_sheet(sheet).conditional_formatting.add(cell_range, rule)

    def add_cell_highlight_rule(self, sheet: str, cell_range: str, operator: str,
                                 formula: List[str], fill_color: str = "FFC7CE"):
        """
        operator examples: 'greaterThan', 'lessThan', 'equal', 'between'
        formula: list of formula strings, e.g. ['100']
        """
        fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
        rule = CellIsRule(operator=operator, formula=formula, fill=fill)
        self.get_sheet(sheet).conditional_formatting.add(cell_range, rule)

    def add_formula_rule(self, sheet: str, cell_range: str, formula: str, fill_color: str = "FFEB9C"):
        fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
        rule = FormulaRule(formula=[formula], fill=fill)
        self.get_sheet(sheet).conditional_formatting.add(cell_range, rule)

    def add_data_bars(self, sheet: str, cell_range: str, color: str = "638EC6"):
        rule = DataBarRule(start_type="min", end_type="max", color=color)
        self.get_sheet(sheet).conditional_formatting.add(cell_range, rule)

    # ------------------------------------------------------------------ #
    # Charts
    # ------------------------------------------------------------------ #
    def add_bar_chart(self, sheet: str, data_range: str, categories_range: str,
                       anchor: str = "E2", title: str = "", x_title: str = "", y_title: str = ""):
        ws = self.get_sheet(sheet)
        chart = BarChart()
        chart.title = title
        chart.x_axis.title = x_title
        chart.y_axis.title = y_title
        data = Reference(ws, range_string=f"{sheet}!{data_range}")
        cats = Reference(ws, range_string=f"{sheet}!{categories_range}")
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)
        ws.add_chart(chart, anchor)
        return chart

    def add_line_chart(self, sheet: str, data_range: str, categories_range: str,
                        anchor: str = "E2", title: str = ""):
        ws = self.get_sheet(sheet)
        chart = LineChart()
        chart.title = title
        data = Reference(ws, range_string=f"{sheet}!{data_range}")
        cats = Reference(ws, range_string=f"{sheet}!{categories_range}")
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)
        ws.add_chart(chart, anchor)
        return chart

    def add_pie_chart(self, sheet: str, data_range: str, categories_range: str,
                       anchor: str = "E2", title: str = ""):
        ws = self.get_sheet(sheet)
        chart = PieChart()
        chart.title = title
        data = Reference(ws, range_string=f"{sheet}!{data_range}")
        cats = Reference(ws, range_string=f"{sheet}!{categories_range}")
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)
        ws.add_chart(chart, anchor)
        return chart

    def add_scatter_chart(self, sheet: str, x_range: str, y_range: str,
                           anchor: str = "E2", title: str = ""):
        ws = self.get_sheet(sheet)
        chart = ScatterChart()
        chart.title = title
        xvalues = Reference(ws, range_string=f"{sheet}!{x_range}")
        yvalues = Reference(ws, range_string=f"{sheet}!{y_range}")
        series = Series(yvalues, xvalues, title_from_data=True)
        chart.series.append(series)
        ws.add_chart(chart, anchor)
        return chart

    # ------------------------------------------------------------------ #
    # Images
    # ------------------------------------------------------------------ #
    def insert_image(self, sheet: str, image_path: str, anchor: str = "A1"):
        img = XLImage(image_path)
        self.get_sheet(sheet).add_image(img, anchor)

    # ------------------------------------------------------------------ #
    # Native Excel Tables
    # ------------------------------------------------------------------ #
    def add_table(self, sheet: str, cell_range: str, table_name: str, style: str = "TableStyleMedium9"):
        ws = self.get_sheet(sheet)
        table = Table(displayName=table_name, ref=cell_range)
        table.tableStyleInfo = TableStyleInfo(
            name=style, showFirstColumn=False, showLastColumn=False,
            showRowStripes=True, showColumnStripes=False,
        )
        ws.add_table(table)
        return table

    # ------------------------------------------------------------------ #
    # Protection
    # ------------------------------------------------------------------ #
    def protect_sheet(self, sheet: str, password: Optional[str] = None):
        self.get_sheet(sheet).protection.sheet = True
        if password:
            self.get_sheet(sheet).protection.password = password

    def unprotect_sheet(self, sheet: str):
        self.get_sheet(sheet).protection.sheet = False

    def lock_cells(self, sheet: str, cell_range: str, locked: bool = True):
        """Only takes effect once protect_sheet() is also called."""
        for row in self.get_sheet(sheet)[cell_range]:
            for cell in row:
                cell.protection = cell.protection.copy(locked=locked)

    # ------------------------------------------------------------------ #
    # pandas interop (optional; requires pandas installed)
    # ------------------------------------------------------------------ #
    def write_dataframe(self, sheet: str, df, start_row: int = 1, start_col: int = 1,
                         index: bool = False, header: bool = True):
        """Write a pandas DataFrame into a sheet."""
        ws = self.get_sheet(sheet)
        for r_off, row in enumerate(dataframe_to_rows(df, index=index, header=header)):
            for c_off, val in enumerate(row):
                ws.cell(row=start_row + r_off, column=start_col + c_off, value=val)

    def read_dataframe(self, sheet: str, header: bool = True):
        """Read a sheet into a pandas DataFrame."""
        import pandas as pd
        data = self.read_all(sheet)
        if header:
            return pd.DataFrame(data[1:], columns=data[0])
        return pd.DataFrame(data)

    # ------------------------------------------------------------------ #
    # Static utility helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def col_letter(index: int) -> str:
        """1 -> 'A', 27 -> 'AA', etc."""
        return get_column_letter(index)

    @staticmethod
    def col_index(letter: str) -> int:
        """'A' -> 1, 'AA' -> 27, etc."""
        return column_index_from_string(letter)

    @staticmethod
    def cell_address(row: int, col: int) -> str:
        return f"{get_column_letter(col)}{row}"


# ---------------------------------------------------------------------- #
# Quick self-test / demo when run directly
# ---------------------------------------------------------------------- #
if __name__ == "__main__":
    xl = ExcelUtil.new()
    ws_name = "Demo"
    xl.create_sheet(ws_name)
    xl.delete_sheet("Sheet")  # remove default sheet

    xl.write_row(ws_name, 1, ["Name", "Score", "Passed"])
    xl.write_row(ws_name, 2, ["Alice", 92, True])
    xl.write_row(ws_name, 3, ["Bob", 67, False])
    xl.write_row(ws_name, 4, ["Carol", 88, True])

    xl.bold_range(ws_name, "A1:C1")
    xl.set_fill(ws_name, "A1:C1", color="D9E1F2")
    xl.set_border(ws_name, "A1:C4")
    xl.autosize_columns(ws_name)
    xl.freeze_panes(ws_name, "A2")
    xl.auto_filter(ws_name, "A1:C4")

    xl.write_formula(ws_name, "B5", "=AVERAGE(B2:B4)")
    xl.add_cell_highlight_rule(ws_name, "B2:B4", operator="lessThan", formula=["70"])

    xl.add_bar_chart(ws_name, data_range="B1:B4", categories_range="A2:A4",
                      anchor="E2", title="Scores", x_title="Student", y_title="Score")

    out_path = "excel_util_demo.xlsx"
    xl.save(out_path)
    print(f"Demo workbook written to {out_path}")
