package com.sts.sample.controller;

import com.sts.sample.exception.BadRequestException;
import com.sts.sample.exception.ResourceNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleRestAdviceController {

    @GetMapping("/resource")
    public String getResource(@RequestParam(required = false) String id) {
        if (id == null) {
            throw new ResourceNotFoundException("Resource ID is missing");
        }
        if ("bad".equals(id)) {
            throw new BadRequestException("Invalid resource ID");
        }
        // Handle resource retrieval logic here
        return "Resource data";
    }
}