package com.sts.sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestContAdviceSampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
