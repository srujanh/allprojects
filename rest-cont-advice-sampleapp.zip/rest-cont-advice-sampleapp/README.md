
http://localhost:9091/resource


Examples:
Request without parameters:

URL: http://localhost:9091/resource
Expected Response: If id is not provided, it will trigger a ResourceNotFoundException, returning a 404 Not Found with an error response.
Request with a valid parameter:

URL: http://localhost:9091/resource?id=someId
Expected Response: If id is provided and is not "bad", it will return "Resource data".
Request with a bad parameter:

URL: http://localhost:9091/resource?id=bad
Expected Response: This will trigger a BadRequestException, returning a 400 Bad Request with an error response.